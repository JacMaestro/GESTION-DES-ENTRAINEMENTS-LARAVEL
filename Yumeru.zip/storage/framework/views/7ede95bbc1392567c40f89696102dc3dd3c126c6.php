
    <!-- Custom fonts for this template-->
    <link href="<?php echo e(asset('assets/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="<?php echo e(asset('assets/css/sb-admin-2.min.css')); ?>" rel="stylesheet">
    <!-- <link href="<?php echo e(asset('assets/css/black-dashboard.min.css')); ?>" rel="stylesheet"> -->

    <link href="<?php echo e(asset('assets/js/toastr/toastr.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <?php
    header("Expires: on, 01 Jan 1970 00:00:00 GMT");
    header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
    header("Cache-Control: no-store, no-cache, must-revalidate");
    header("Cache-Control: post-check=0, pre-check=0", false);
    header("Pragma: no-cache");
    ?>

<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>



    <?php /**PATH C:\DELL\etc\Yumeru\resources\views/public/css.blade.php ENDPATH**/ ?>